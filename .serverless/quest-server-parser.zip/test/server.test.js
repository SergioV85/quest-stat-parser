const chai = require('chai');
const request = require('request');

const expect = chai.expect;

describe('Server application', () => {
  describe('GET /games', () => {});
  describe('POST /games', () => {});
  describe('PUT /games/:gameId/update-levels', () => {});
});
