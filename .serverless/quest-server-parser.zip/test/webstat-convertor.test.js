const chai = require('chai');
const webstatConvertor = require('./../modules/webstat-convertor');

const expect = chai.expect;

describe('Database Connection Module', () => {
  describe('getGameInfo', () => {});
  describe('getGameStat', () => {});
});
