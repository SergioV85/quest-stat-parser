const chai = require('chai');
const timeParser = require('./../modules/parsers/time-parser');

const expect = chai.expect;

describe('TimeParser Module', () => {
  describe('convertTime', () => {});
});
