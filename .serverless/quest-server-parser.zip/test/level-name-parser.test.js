const chai = require('chai');
const levelNameParser = require('./../modules/parsers/level-name-parser');

const expect = chai.expect;

describe('Level Name Parser Module', () => {
  describe('getNames', () => {

  });
});
