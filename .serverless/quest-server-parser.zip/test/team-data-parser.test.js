const chai = require('chai');
const teamDataParser = require('./../modules/parsers/team-data-parser');

const expect = chai.expect;

describe('Team Data Parser Module', () => {
  describe('getStat', () => {});
  describe('getStatByTeam', () => {});
  describe('getStatByLevel', () => {});
  describe('getFinishResults', () => {});
});
